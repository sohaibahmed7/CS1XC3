/**
 * @file course.h
 * @author Sohaib Ahmed
 * @date 04/12/2022
 * @brief A struct for the course which includes its name, course code, # of students enrolled in that course, and # of students overall.
 * 
 */
#include "student.h"
#include <stdbool.h>

typedef struct _course 
{
  char name[100]; /**< course name */
  char code[10]; /**< course code */
  Student *students; /**< students enrolled in the course */
  int total_students; /**< students enrolled */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


