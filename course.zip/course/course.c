/**
 * @file course.c
 * @author Sohaib Ahmed
 * @date 04/12/2022
 * @brief Set of functions involving course's. Such as enrolling students, listing courses, finding the highest average, & finding passing students
 *
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Adds a new student to a specific course by appending them to the end of a list.
 *
 * @param course
 * @param student
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student)); //Initializes the size of the list with calloc if empty...
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); //...otherwise resizes the size of the list using realloc
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints information regarding a course, inclusing name, course code, total # of students enrolled in a course, and # of students enrolled in that specific course.
 *
 * @param course
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Returns the information of the student with the highest average in the course.
 *
 * @param course
 * @return student
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average; //Checks all the students for the highest average
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Returns a list of the the students who are passing the course with an average greater thaan or equal to 50%.
 *
 * @param course
 * @param total_passing
 * @return passing
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student)); //Dynamically allocates space for the array to store the passing students

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}