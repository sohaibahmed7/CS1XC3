/**
 * @file student.h
 * @author Sohaib Ahmed
 * @date 04/12/2022
 *
 */

/**
 * @brief A struct for the student which includes their first and last name, student ID, a list of their grades, and total number of grades.
 */
typedef struct _student 
{ 
  char first_name[50]; /**< student first name */
  char last_name[50]; /**< student last name */
  char id[11]; /**< student ID*/
  double *grades; /**< value of student's grades */
  int num_grades; /**< # of student's grades */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
