/**
 * @file course.h
 */
#include "student.h"
#include <stdbool.h>

/**
 * @brief A struct for the course which includes its name, course code, # of students enrolled in that course, and # of students overall.
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


